Create a simple MCP server for Claude Code using Node.js.

The server should have three tools:

1. "save_note" - Takes a title (string) and content (string), saves the
   content as a markdown file in ~/dev-notes/ using the title as the
   filename (slugified, e.g. "Project Ideas" → "project-ideas.md").
   Creates the ~/dev-notes/ directory if it doesn't exist.

2. "list_notes" - Takes no parameters, returns a list of all .md files
   in ~/dev-notes/ with their titles and last-modified dates.

3. "read_note" - Takes a title (string), finds the matching .md file in
   ~/dev-notes/, and returns its contents.

Please create:

1. package.json with the @modelcontextprotocol/sdk dependency
2. index.js with the complete server code using McpServer and StdioServerTransport
3. Add clear comments explaining what each part does

Keep it simple - this is my first MCP server.

## Summary

✅ **Completed**

Created a fully functional MCP server with the following:

- **package.json** - Configured with @modelcontextprotocol/sdk v1.26.0 and npm start script
- **index.js** - Complete server implementation (240+ lines) with:
  - Three tools: save_note, list_notes, read_note
  - Slugify helper function to convert titles to safe filenames
  - Automatic ~/dev-notes/ directory creation
  - Comprehensive error handling
  - Clear JSDoc comments explaining each function
  - StdioServerTransport for Claude Code integration

All tools are fully implemented and ready to use. The server can be started with `npm start`.
#!/usr/bin/env node

/**
 * Test script for the Dev Notes MCP Server
 * Sends MCP protocol messages to test the server functionality
 */

const { spawn } = require("child_process");
const path = require("path");

// Start the server as a child process
const serverProcess = spawn("node", ["index.js"], {
  cwd: __dirname,
  stdio: ["pipe", "pipe", "pipe"],
});

let messageId = 1;
const responses = [];

/**
 * Send a JSON-RPC message to the server
 */
function sendMessage(method, params = {}) {
  const message = {
    jsonrpc: "2.0",
    id: messageId++,
    method,
    params,
  };

  console.log(`\n→ Sending: ${method}`);
  console.log(JSON.stringify(message, null, 2));

  serverProcess.stdin.write(JSON.stringify(message) + "\n");
}

/**
 * Listen for responses from the server
 */
let buffer = "";
serverProcess.stdout.on("data", (data) => {
  buffer += data.toString();

  // Process complete JSON lines
  const lines = buffer.split("\n");
  buffer = lines[lines.length - 1]; // Keep incomplete line in buffer

  for (let i = 0; i < lines.length - 1; i++) {
    const line = lines[i].trim();
    if (line) {
      try {
        const response = JSON.parse(line);
        responses.push(response);
        console.log(`\n← Received: ${response.result ? "Result" : "Error"}`);
        console.log(JSON.stringify(response, null, 2));
      } catch (e) {
        console.error(`Failed to parse response: ${line}`);
      }
    }
  }
});

// Handle server errors
serverProcess.stderr.on("data", (data) => {
  console.error(`Server stderr: ${data.toString()}`);
});

// Start test sequence with delays
setTimeout(() => {
  console.log("=== Starting MCP Server Tests ===\n");

  // Step 1: Initialize
  sendMessage("initialize", {
    protocolVersion: "2024-11-05",
    capabilities: {},
    clientInfo: {
      name: "test-client",
      version: "1.0.0",
    },
  });

  // Step 2: List tools (after a delay to allow initialization)
  setTimeout(() => {
    sendMessage("tools/list");

    // Step 3: Save a note
    setTimeout(() => {
      sendMessage("tools/call", {
        name: "save_note",
        arguments: {
          title: "Test Note",
          content: "# Test Note\n\nThis is a test note created by the test script.",
        },
      });

      // Step 4: List notes
      setTimeout(() => {
        sendMessage("tools/call", {
          name: "list_notes",
          arguments: {},
        });

        // Step 5: Read the note
        setTimeout(() => {
          sendMessage("tools/call", {
            name: "read_note",
            arguments: {
              title: "Test Note",
            },
          });

          // Close server after final test
          setTimeout(() => {
            console.log("\n=== Tests Complete ===\n");
            serverProcess.kill();
            process.exit(0);
          }, 1000);
        }, 500);
      }, 500);
    }, 500);
  }, 500);
}, 100);

// Handle process termination
serverProcess.on("close", (code) => {
  if (code !== null && code !== 0) {
    console.error(`Server process exited with code ${code}`);
    process.exit(1);
  }
});
